# MT5 Living Bots – Real-time 3D Dashboard

Cinematic real-time visualization of **4 MetaTrader 5 Expert Advisors**.

Inspired by Gaploid/stardust.  
Four living particle spheres that react to PnL, exposure and market state.

## Features

- Living spheres – particle clouds with state-driven behavior
  - Flat → quiet breathing
  - Winning → energetic rotation + rising particles + stronger glow
  - Losing → heavy / tired motion + falling particles
- Real-time account panel – balance, total PnL (€ + %), starting from 1 350 €
- Per-bot details on click
- Cinema mode – automatic camera tour
- Secure architecture – frontend never sees MT5 credentials
- High-quality post-processing (Bloom, Vignette, Chromatic Aberration)

## Tech Stack

- Next.js 15 (App Router) + TypeScript
- React Three Fiber + Drei + Postprocessing
- Zustand
- Tailwind CSS v4
- WebSocket for live data

## Quick Start

```bash
npm install
cp .env.example .env.local
npm run dev
```

Open http://localhost:3000 (mock data works immediately).

## Connecting to real MT5

Frontend NEVER receives credentials.  
Use a secure backend/bridge (MetaApi, custom VPS, etc.) that pushes AccountData JSON over WebSocket.

Set:
NEXT_PUBLIC_WS_URL=wss://your-secure-bridge.example.com/ws

## License

MIT
