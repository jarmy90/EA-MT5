"use client";

import { useRef, useMemo } from "react";
import { useFrame } from "@react-three/fiber";
import { Sphere, Float } from "@react-three/drei";
import * as THREE from "three";
import type { BotData } from "@/types";

interface SphereBotProps {
  bot: BotData;
  position: [number, number, number];
  isSelected: boolean;
  onSelect: () => void;
}

export function SphereBot({ bot, position, isSelected, onSelect }: SphereBotProps) {
  const meshRef = useRef<THREE.Mesh>(null);
  const particlesRef = useRef<THREE.Points>(null);
  const glowRef = useRef<THREE.Mesh>(null);

  const particleCount = 1800;
  const { positions, colors } = useMemo(() => {
    const pos = new Float32Array(particleCount * 3);
    const col = new Float32Array(particleCount * 3);
    for (let i = 0; i < particleCount; i++) {
      const r = 0.85 + Math.random() * 0.35;
      const theta = Math.random() * Math.PI * 2;
      const phi = Math.acos(2 * Math.random() - 1);
      pos[i * 3] = r * Math.sin(phi) * Math.cos(theta);
      pos[i * 3 + 1] = r * Math.sin(phi) * Math.sin(theta);
      pos[i * 3 + 2] = r * Math.cos(phi);

      // base color will be modulated in shader/useFrame
      col[i * 3] = 0.4;
      col[i * 3 + 1] = 0.7;
      col[i * 3 + 2] = 1.0;
    }
    return { positions: pos, colors: col };
  }, []);

  // Scale based on exposure
  const baseScale = 0.7 + (bot.exposurePct / 100) * 1.1;

  useFrame((state, delta) => {
    if (!meshRef.current || !particlesRef.current || !glowRef.current) return;

    const t = state.clock.elapsedTime;
    const mesh = meshRef.current;
    const particles = particlesRef.current;
    const glow = glowRef.current;

    // Color according to state / PnL
    let targetColor = new THREE.Color("#6b8cae"); // neutral
    if (bot.state === "long" || bot.pnl > 5) targetColor = new THREE.Color("#3dd68c");
    if (bot.state === "short" || bot.pnl < -5) targetColor = new THREE.Color("#ff5c5c");
    if (bot.pnl > 30) targetColor = new THREE.Color("#5ef0b0");
    if (bot.pnl < -20) targetColor = new THREE.Color("#ff3333");

    // Animate rotation & "breathing"
    if (bot.state === "flat" && Math.abs(bot.pnl) < 1) {
      // Quiet breathing
      mesh.rotation.y += delta * 0.08;
      mesh.position.y = position[1] + Math.sin(t * 0.6) * 0.04;
      glow.scale.setScalar(baseScale * (1.15 + Math.sin(t * 0.8) * 0.03));
    } else if (bot.pnl > 0) {
      // Winning – energetic rotation + lift
      mesh.rotation.y += delta * (0.35 + Math.min(bot.pnl / 80, 0.6));
      mesh.rotation.x = Math.sin(t * 0.9) * 0.08;
      mesh.position.y = position[1] + 0.15 + Math.sin(t * 1.2) * 0.06;
      glow.scale.setScalar(baseScale * (1.25 + Math.sin(t * 1.5) * 0.08));
    } else {
      // Losing – tired / heavy movement
      mesh.rotation.y += delta * 0.12;
      mesh.rotation.z = Math.sin(t * 0.7) * 0.15;
      mesh.position.y = position[1] - 0.1 + Math.sin(t * 0.5) * 0.05;
      glow.scale.setScalar(baseScale * (1.05 + Math.sin(t * 0.4) * 0.04));
    }

    // Update particle colors
    const colorAttr = particles.geometry.getAttribute("color") as THREE.BufferAttribute;
    const posAttr = particles.geometry.getAttribute("position") as THREE.BufferAttribute;
    for (let i = 0; i < particleCount; i++) {
      const i3 = i * 3;
      // slight outward drift when winning
      if (bot.pnl > 0) {
        const ox = posAttr.array[i3];
        const oy = posAttr.array[i3 + 1];
        const oz = posAttr.array[i3 + 2];
        const len = Math.sqrt(ox * ox + oy * oy + oz * oz) || 1;
        posAttr.array[i3] += (ox / len) * delta * 0.01 * (bot.pnl / 50);
        posAttr.array[i3 + 1] += (oy / len) * delta * 0.01 * (bot.pnl / 50) + delta * 0.008;
        posAttr.array[i3 + 2] += (oz / len) * delta * 0.01 * (bot.pnl / 50);
      } else if (bot.pnl < -5) {
        posAttr.array[i3 + 1] -= delta * 0.012;
      }

      colorAttr.array[i3] = targetColor.r;
      colorAttr.array[i3 + 1] = targetColor.g;
      colorAttr.array[i3 + 2] = targetColor.b;
    }
    colorAttr.needsUpdate = true;
    posAttr.needsUpdate = true;

    // Material color
    if (mesh.material instanceof THREE.MeshStandardMaterial) {
      mesh.material.color.lerp(targetColor, 0.05);
      mesh.material.emissive.lerp(targetColor, 0.04);
      mesh.material.emissiveIntensity = bot.pnl > 0 ? 0.45 + Math.min(bot.pnl / 100, 0.4) : 0.15;
    }
    if (glow.material instanceof THREE.MeshBasicMaterial) {
      glow.material.color.lerp(targetColor, 0.06);
      glow.material.opacity = isSelected ? 0.35 : 0.18;
    }
  });

  return (
    <group position={position}>
      <Float speed={bot.state === "flat" ? 0.6 : 1.4} rotationIntensity={0.15} floatIntensity={0.3}>
        {/* Core sphere */}
        <Sphere
          ref={meshRef}
          args={[1, 64, 64]}
          scale={baseScale}
          onClick={(e) => {
            e.stopPropagation();
            onSelect();
          }}
          onPointerOver={() => (document.body.style.cursor = "pointer")}
          onPointerOut={() => (document.body.style.cursor = "auto")}
        >
          <meshStandardMaterial
            color="#6b8cae"
            emissive="#6b8cae"
            emissiveIntensity={0.25}
            roughness={0.25}
            metalness={0.6}
            transparent
            opacity={0.92}
          />
        </Sphere>

        {/* Soft glow shell */}
        <Sphere ref={glowRef} args={[1.15, 32, 32]} scale={baseScale}>
          <meshBasicMaterial color="#6b8cae" transparent opacity={0.18} depthWrite={false} />
        </Sphere>

        {/* Particle cloud */}
        <points ref={particlesRef}>
          <bufferGeometry>
            <bufferAttribute
              attach="attributes-position"
              count={particleCount}
              array={positions}
              itemSize={3}
            />
            <bufferAttribute
              attach="attributes-color"
              count={particleCount}
              array={colors}
              itemSize={3}
            />
          </bufferGeometry>
          <pointsMaterial
            size={0.035}
            vertexColors
            transparent
            opacity={0.85}
            sizeAttenuation
            depthWrite={false}
            blending={THREE.AdditiveBlending}
          />
        </points>
      </Float>

      {/* Name label (simple) */}
      {isSelected && (
        <group position={[0, baseScale + 1.4, 0]}>
          {/* Label is handled by HTML overlay for sharpness */}
        </group>
      )}
    </group>
  );
}
