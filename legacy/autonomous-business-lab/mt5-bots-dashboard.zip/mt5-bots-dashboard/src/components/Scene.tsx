"use client";

import { Canvas } from "@react-three/fiber";
import { OrbitControls, Stars, AdaptiveDpr, AdaptiveEvents } from "@react-three/drei";
import { EffectComposer, Bloom, Vignette, ChromaticAberration } from "@react-three/postprocessing";
import { Suspense, useRef } from "react";
import { SphereBot } from "./SphereBot";
import { useDashboardStore } from "@/store/useDashboardStore";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";

const BOT_POSITIONS: [number, number, number][] = [
  [-3.2, 0.3, 0],
  [3.2, 0.3, 0],
  [0, 0.3, -3.2],
  [0, 0.3, 3.2],
];

function CinemaCamera() {
  const { cinemaMode, account } = useDashboardStore();
  const controlsRef = useRef<any>(null);

  useFrame((state) => {
    if (!cinemaMode || !controlsRef.current) return;
    const t = state.clock.elapsedTime * 0.15;
    const radius = 9;
    state.camera.position.x = Math.sin(t) * radius;
    state.camera.position.z = Math.cos(t) * radius;
    state.camera.position.y = 2.5 + Math.sin(t * 0.7) * 0.8;
    state.camera.lookAt(0, 0.2, 0);
  });

  return (
    <OrbitControls
      ref={controlsRef}
      enablePan={false}
      minDistance={5}
      maxDistance={18}
      maxPolarAngle={Math.PI / 1.7}
      enabled={!cinemaMode}
    />
  );
}

function SceneContent() {
  const { account, selectedBotId, selectBot } = useDashboardStore();

  return (
    <>
      <color attach="background" args={["#03050a"]} />
      <fog attach="fog" args={["#03050a", 12, 28]} />

      <ambientLight intensity={0.25} />
      <pointLight position={[8, 10, 6]} intensity={1.2} color="#a0c4ff" />
      <pointLight position={[-8, 6, -6]} intensity={0.6} color="#ffb3c1" />

      <Stars radius={80} depth={50} count={4000} factor={3} saturation={0} fade speed={0.4} />

      {account.bots.map((bot, i) => (
        <SphereBot
          key={bot.id}
          bot={bot}
          position={BOT_POSITIONS[i]}
          isSelected={selectedBotId === bot.id}
          onSelect={() => selectBot(selectedBotId === bot.id ? null : bot.id)}
        />
      ))}

      <CinemaCamera />

      <EffectComposer multisampling={0}>
        <Bloom
          intensity={1.1}
          luminanceThreshold={0.15}
          luminanceSmoothing={0.7}
          mipmapBlur
        />
        <Vignette eskil={false} offset={0.15} darkness={0.75} />
        <ChromaticAberration
          offset={new THREE.Vector2(0.0006, 0.0006)}
          radialModulation={false}
          modulationOffset={0}
        />
      </EffectComposer>
    </>
  );
}

export function Scene() {
  return (
    <div className="absolute inset-0 z-0">
      <Canvas
        camera={{ position: [0, 3.5, 10], fov: 45, near: 0.1, far: 100 }}
        dpr={[1, 1.8]}
        gl={{ antialias: true, alpha: false, powerPreference: "high-performance" }}
      >
        <Suspense fallback={null}>
          <SceneContent />
          <AdaptiveDpr pixelated />
          <AdaptiveEvents />
        </Suspense>
      </Canvas>
    </div>
  );
}
