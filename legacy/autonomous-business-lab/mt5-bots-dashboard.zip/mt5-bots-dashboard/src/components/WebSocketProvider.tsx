"use client";

import { useEffect, useRef } from "react";
import { useDashboardStore } from "@/store/useDashboardStore";
import type { AccountData, BotData } from "@/types";

/**
 * In production this connects to your secure backend WebSocket
 * that talks to MT5 (MetaApi, custom bridge, etc.).
 * Credentials NEVER leave the backend.
 *
 * Set NEXT_PUBLIC_WS_URL in .env to your real endpoint.
 * While developing we simulate realistic data so the visuals work immediately.
 */
export function WebSocketProvider({ children }: { children: React.ReactNode }) {
  const setAccount = useDashboardStore((s) => s.setAccount);
  const addMoment = useDashboardStore((s) => s.addMoment);
  const prevPnls = useRef<Record<string, number>>({});

  useEffect(() => {
    const wsUrl = process.env.NEXT_PUBLIC_WS_URL;

    // ---------- REAL WebSocket (when you have a backend) ----------
    if (wsUrl) {
      const ws = new WebSocket(wsUrl);

      ws.onmessage = (event) => {
        try {
          const data: AccountData = JSON.parse(event.data);
          // Detect big profit moments
          data.bots.forEach((bot) => {
            const prev = prevPnls.current[bot.id] ?? bot.pnl;
            if (bot.pnl - prev > 25) {
              addMoment({
                botId: bot.id,
                botName: bot.name,
                pnl: bot.pnl,
                timestamp: Date.now(),
                message: `${bot.name} just made a strong move`,
              });
            }
            prevPnls.current[bot.id] = bot.pnl;
          });
          setAccount(data);
        } catch (e) {
          console.error("Invalid WS message", e);
        }
      };

      ws.onerror = () => console.warn("WebSocket error – falling back to mock");
      return () => ws.close();
    }

    // ---------- MOCK simulation (default) ----------
    const interval = setInterval(() => {
      const current = useDashboardStore.getState().account;
      const bots: BotData[] = current.bots.map((b) => {
        // random walk biased by current state
        let delta = (Math.random() - 0.48) * 3.5;
        if (b.state === "long") delta += 0.4;
        if (b.state === "short") delta -= 0.3;
        if (b.state === "flat") delta *= 0.15;

        const newPnl = Math.round((b.pnl + delta) * 100) / 100;
        let newState = b.state;
        if (Math.random() < 0.015) {
          // occasional state change
          const r = Math.random();
          newState = r < 0.35 ? "flat" : r < 0.7 ? "long" : "short";
        }

        return {
          ...b,
          pnl: newPnl,
          state: newState,
          exposurePct:
            newState === "flat"
              ? Math.max(0, b.exposurePct - 2)
              : Math.min(40, b.exposurePct + (Math.random() - 0.3) * 1.5),
        };
      });

      const totalPnl = bots.reduce((s, b) => s + b.pnl, 0);
      const balance = current.startingBalance + totalPnl;

      setAccount({
        ...current,
        bots,
        totalPnl,
        balance,
        equity: balance,
        totalPnlPct: (totalPnl / current.startingBalance) * 100,
        lastUpdate: Date.now(),
      });
    }, 1800);

    return () => clearInterval(interval);
  }, [setAccount, addMoment]);

  return <>{children}</>;
}
