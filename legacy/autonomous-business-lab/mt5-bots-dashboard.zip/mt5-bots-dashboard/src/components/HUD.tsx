"use client";

import { useDashboardStore } from "@/store/useDashboardStore";

export function HUD() {
  const { account, selectedBotId, cinemaMode, soundEnabled, toggleCinema, toggleSound, selectBot } =
    useDashboardStore();

  const selectedBot = account.bots.find((b) => b.id === selectedBotId);
  const isProfit = account.totalPnl >= 0;

  return (
    <div className="pointer-events-none absolute inset-0 z-10 flex flex-col justify-between p-4 md:p-6 text-white">
      {/* Top bar */}
      <div className="pointer-events-auto flex flex-wrap items-start justify-between gap-4">
        <div>
          <h1 className="text-xl md:text-2xl font-light tracking-widest text-white/90">
            MT5 <span className="font-semibold text-cyan-300">LIVING BOTS</span>
          </h1>
          <p className="text-xs text-white/40 mt-0.5">Real-time 3D visualization</p>
        </div>

        <div className="flex gap-2">
          <button
            onClick={toggleCinema}
            className={`px-3 py-1.5 rounded-full text-xs border transition ${
              cinemaMode
                ? "bg-cyan-500/20 border-cyan-400 text-cyan-200"
                : "bg-white/5 border-white/15 text-white/60 hover:bg-white/10"
            }`}
          >
            {cinemaMode ? "● Cinema ON" : "Cinema"}
          </button>
          <button
            onClick={toggleSound}
            className={`px-3 py-1.5 rounded-full text-xs border transition ${
              soundEnabled
                ? "bg-cyan-500/20 border-cyan-400 text-cyan-200"
                : "bg-white/5 border-white/15 text-white/60 hover:bg-white/10"
            }`}
          >
            Sound
          </button>
        </div>
      </div>

      {/* Center selected bot panel */}
      {selectedBot && (
        <div className="pointer-events-auto absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-72 max-w-[90vw]">
          <div className="rounded-2xl bg-black/70 backdrop-blur-xl border border-white/10 p-5 shadow-2xl">
            <div className="flex justify-between items-start mb-3">
              <div>
                <h2 className="text-lg font-medium text-white">{selectedBot.name}</h2>
                <p className="text-xs text-white/50 uppercase tracking-wider">{selectedBot.state}</p>
              </div>
              <button
                onClick={() => selectBot(null)}
                className="text-white/40 hover:text-white text-sm"
              >
                ✕
              </button>
            </div>

            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-white/50">PnL flotante</span>
                <span className={selectedBot.pnl >= 0 ? "text-emerald-400" : "text-rose-400"}>
                  {selectedBot.pnl >= 0 ? "+" : ""}
                  {selectedBot.pnl.toFixed(2)} €
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-white/50">Exposición</span>
                <span>{selectedBot.exposurePct.toFixed(1)} %</span>
              </div>
              <div className="flex justify-between">
                <span className="text-white/50">Posiciones</span>
                <span>{selectedBot.openPositions ?? 0}</span>
              </div>
              {selectedBot.winRate !== undefined && (
                <div className="flex justify-between">
                  <span className="text-white/50">Winrate</span>
                  <span>{selectedBot.winRate} %</span>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Bottom account panel */}
      <div className="pointer-events-auto self-center md:self-end w-full max-w-md">
        <div className="rounded-2xl bg-black/65 backdrop-blur-xl border border-white/10 px-5 py-4 shadow-2xl">
          <div className="flex justify-between items-end mb-1">
            <span className="text-xs text-white/40 uppercase tracking-wider">Balance</span>
            <span className="text-2xl font-light tabular-nums">
              {account.balance.toFixed(2)} <span className="text-base text-white/50">€</span>
            </span>
          </div>

          <div className="flex justify-between items-center">
            <span className="text-xs text-white/40">Desde 1.350 €</span>
            <span
              className={`text-sm font-medium tabular-nums ${
                isProfit ? "text-emerald-400" : "text-rose-400"
              }`}
            >
              {isProfit ? "+" : ""}
              {account.totalPnl.toFixed(2)} € ({isProfit ? "+" : ""}
              {account.totalPnlPct.toFixed(2)} %)
            </span>
          </div>

          {/* Mini bots status */}
          <div className="mt-3 flex gap-2">
            {account.bots.map((b) => (
              <button
                key={b.id}
                onClick={() => selectBot(b.id)}
                className={`flex-1 rounded-lg py-1.5 text-[10px] border transition ${
                  selectedBotId === b.id
                    ? "bg-white/15 border-white/30"
                    : "bg-white/5 border-white/10 hover:bg-white/10"
                }`}
              >
                <div className="font-medium truncate">{b.name}</div>
                <div
                  className={`tabular-nums ${
                    b.pnl >= 0 ? "text-emerald-400/90" : "text-rose-400/90"
                  }`}
                >
                  {b.pnl >= 0 ? "+" : ""}
                  {b.pnl.toFixed(1)}
                </div>
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
