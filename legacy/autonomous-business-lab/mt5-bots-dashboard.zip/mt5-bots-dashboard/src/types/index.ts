export type BotState = "flat" | "long" | "short";

export interface BotData {
  id: string;
  name: string;
  pnl: number;           // floating PnL in EUR
  exposurePct: number;   // % of total balance used by this bot
  state: BotState;
  winRate?: number;
  openPositions?: number;
}

export interface AccountData {
  balance: number;
  equity: number;
  startingBalance: number; // 1350
  totalPnl: number;
  totalPnlPct: number;
  bots: BotData[];
  lastUpdate: number;
}

export interface Moment {
  id: string;
  botId: string;
  botName: string;
  pnl: number;
  timestamp: number;
  message: string;
}
