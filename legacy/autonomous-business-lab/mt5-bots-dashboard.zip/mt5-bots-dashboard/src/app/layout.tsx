import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "MT5 Living Bots | Real-time 3D Dashboard",
  description:
    "Cinematic real-time visualization of 4 MetaTrader 5 Expert Advisors. Living spheres that react to PnL, exposure and market state.",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className="dark">
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-[#03050a] text-white overflow-hidden`}
      >
        {children}
      </body>
    </html>
  );
}
