"use client";

import { Scene } from "@/components/Scene";
import { HUD } from "@/components/HUD";
import { WebSocketProvider } from "@/components/WebSocketProvider";

export default function Home() {
  return (
    <WebSocketProvider>
      <main className="relative h-screen w-screen overflow-hidden bg-[#03050a]">
        <Scene />
        <HUD />
      </main>
    </WebSocketProvider>
  );
}
