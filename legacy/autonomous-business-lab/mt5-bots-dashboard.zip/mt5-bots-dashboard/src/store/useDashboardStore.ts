"use client";

import { create } from "zustand";
import type { AccountData, BotData, Moment } from "@/types";

interface DashboardState {
  account: AccountData;
  moments: Moment[];
  selectedBotId: string | null;
  cinemaMode: boolean;
  soundEnabled: boolean;

  setAccount: (data: AccountData) => void;
  updateBot: (botId: string, partial: Partial<BotData>) => void;
  selectBot: (id: string | null) => void;
  toggleCinema: () => void;
  toggleSound: () => void;
  addMoment: (moment: Omit<Moment, "id">) => void;
}

const INITIAL_BALANCE = 1350;

const mockBots: BotData[] = [
  { id: "bot-1", name: "Aurora", pnl: 42.5, exposurePct: 18, state: "long", winRate: 62, openPositions: 2 },
  { id: "bot-2", name: "Nebula", pnl: -12.3, exposurePct: 9, state: "short", winRate: 55, openPositions: 1 },
  { id: "bot-3", name: "Pulsar", pnl: 0, exposurePct: 0, state: "flat", winRate: 71, openPositions: 0 },
  { id: "bot-4", name: "Quasar", pnl: 87.1, exposurePct: 24, state: "long", winRate: 68, openPositions: 3 },
];

const totalPnl = mockBots.reduce((s, b) => s + b.pnl, 0);
const balance = INITIAL_BALANCE + totalPnl;

export const useDashboardStore = create<DashboardState>((set, get) => ({
  account: {
    balance,
    equity: balance,
    startingBalance: INITIAL_BALANCE,
    totalPnl,
    totalPnlPct: (totalPnl / INITIAL_BALANCE) * 100,
    bots: mockBots,
    lastUpdate: Date.now(),
  },
  moments: [],
  selectedBotId: null,
  cinemaMode: false,
  soundEnabled: false,

  setAccount: (data) => set({ account: data }),

  updateBot: (botId, partial) =>
    set((state) => {
      const bots = state.account.bots.map((b) =>
        b.id === botId ? { ...b, ...partial } : b
      );
      const totalPnl = bots.reduce((s, b) => s + b.pnl, 0);
      const balance = state.account.startingBalance + totalPnl;
      return {
        account: {
          ...state.account,
          bots,
          totalPnl,
          balance,
          equity: balance,
          totalPnlPct: (totalPnl / state.account.startingBalance) * 100,
          lastUpdate: Date.now(),
        },
      };
    }),

  selectBot: (id) => set({ selectedBotId: id }),

  toggleCinema: () => set((s) => ({ cinemaMode: !s.cinemaMode })),

  toggleSound: () => set((s) => ({ soundEnabled: !s.soundEnabled })),

  addMoment: (moment) =>
    set((s) => ({
      moments: [
        { ...moment, id: `m-${Date.now()}` },
        ...s.moments,
      ].slice(0, 20),
    })),
}));
